# Lint Graph Project

Small multi-project TypeScript/Nx repository for testing the Graph Engineering lint workflow.

Projects:
- apps/order-service
- apps/user-service
- apps/inventory-service
- libs/shared
- libs/config

The source contains multiple categories of intentional lint violations distributed across several projects and files.

Run:
```text
npm install
npm run affected:lint:ci
```
