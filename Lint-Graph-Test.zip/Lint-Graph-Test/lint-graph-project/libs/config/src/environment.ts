export interface AppConfig {
  serviceName: string;
  region: string;
  retryLimit: number;
}

export const config: AppConfig = {
  serviceName: "lint-graph-project",
  region: "central",
  retryLimit: 3
};
