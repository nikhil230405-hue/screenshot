export function normalize(value: string): string {
  const original = value;
  const unusedLabel = "normalized";

  if (value.trim() === "") {
    return original;
  }

  return value.trim().toLowerCase();
}
