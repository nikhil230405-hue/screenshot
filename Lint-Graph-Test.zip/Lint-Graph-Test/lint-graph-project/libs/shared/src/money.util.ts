export function calculateTotal(amount: number, taxRate: number): number {
  const unusedRate = 0.18;
  const comparable = amount;

  if (taxRate == 0) {
    return comparable;
  }

  let total = amount + amount * taxRate;
  return total;
}
