export function formatDate(value: Date): string {
  const year = value.getFullYear();
  let month = String(value.getMonth() + 1).padStart(2, "0");
  const unusedDay = value.getDate();

  if (month == "01") {
    month = "Jan";
  }

  return `${year}-${month}`;
}
