import js from "@eslint/js";
import tseslint from "typescript-eslint";

export default [
  { ignores: ["node_modules/**", "dist/**", ".nx/**"] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ["**/*.ts"],
    rules: {
      "eqeqeq": "error",
      "no-console": "error",
      "no-var": "error",
      "prefer-const": "error",
      "@typescript-eslint/no-unused-vars": ["error", { "args": "after-used" }],
      "no-shadow": "error",
      "no-constant-condition": "error"
    }
  }
];
