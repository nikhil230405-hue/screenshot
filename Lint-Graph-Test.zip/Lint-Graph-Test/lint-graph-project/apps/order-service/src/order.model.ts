export interface Order {
  id: string;
  customerId: string;
  total: number;
  status: "NEW" | "PAID" | "CANCELLED";
}
