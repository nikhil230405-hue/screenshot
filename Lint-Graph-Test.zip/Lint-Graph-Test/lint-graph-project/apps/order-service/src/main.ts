import { OrderService } from "./order.service";

const service = new OrderService();
service.listRecentOrders();

service.shutdown();
