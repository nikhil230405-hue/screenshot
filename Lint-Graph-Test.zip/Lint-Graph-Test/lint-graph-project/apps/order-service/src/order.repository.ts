import { Order } from "./order.model";

export class OrderRepository {
  private readonly orders: Order[] = [
    { id: "o-100", customerId: "u-10", total: 125, status: "PAID" },
    { id: "o-101", customerId: "u-11", total: 80, status: "NEW" },
    { id: "o-102", customerId: "u-12", total: 210, status: "CANCELLED" }
  ];

  findByStatus(status: Order["status"]): Order[] {
    return this.orders.filter((order) => order.status === status);
  }
}
