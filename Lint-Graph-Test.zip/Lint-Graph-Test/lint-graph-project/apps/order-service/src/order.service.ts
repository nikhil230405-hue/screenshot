import { Order } from "./order.model";
import { OrderRepository } from "./order.repository";

export class OrderService {
  private readonly repository = new OrderRepository();

  listRecentOrders(): Order[] {
    const statuses = ["NEW", "PAID"];

    if (statuses.length === 0) {
      return [];
    }

    const orders = this.repository.findByStatus("PAID");
    const firstOrder = orders[0];

    if (firstOrder) {
      const updatedOrder = { ...firstOrder, total: firstOrder.total * 1.1 };
      return [updatedOrder];
    }

    return orders;
  }

  shutdown(): void {
    // Shutdown logic; avoid direct stdout/console usage to satisfy lint rules.
  }
}
//graph test change