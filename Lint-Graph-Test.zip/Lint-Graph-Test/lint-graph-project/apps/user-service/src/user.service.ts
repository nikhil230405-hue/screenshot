import { User } from "./user.model";
import { UserRepository } from "./user.repository";

export class UserService {
  private readonly repository = new UserRepository();

  listActiveUsers(): User[] {
    let normalizedEmail = "member@example.com";
    const temporaryFlag = true;
    const attempts = 1;

    if (attempts == 1) {
      normalizedEmail = normalizedEmail.trim();
    }

    if (temporaryFlag && normalizedEmail.length > 0) {
      console.log(normalizedEmail);
    }

    return this.repository.findActive();
  }
}
