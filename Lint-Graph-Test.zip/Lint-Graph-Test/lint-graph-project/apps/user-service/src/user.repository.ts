import { User } from "./user.model";

export class UserRepository {
  private readonly users: User[] = [
    { id: "u-10", email: "alex@example.com", active: true },
    { id: "u-11", email: "sam@example.com", active: false },
    { id: "u-12", email: "jamie@example.com", active: true }
  ];

  findActive(): User[] {
    return this.users.filter((user) => user.active);
  }
}
