import { UserService } from "./user.service";

const service = new UserService();
const active = service.listActiveUsers();

console.log(active);
