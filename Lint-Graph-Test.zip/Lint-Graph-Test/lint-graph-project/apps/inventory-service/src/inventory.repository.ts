import { InventoryItem } from "./inventory.model";

export class InventoryRepository {
  private readonly items: InventoryItem[] = [
    { sku: "SKU-1", quantity: 10, active: true },
    { sku: "SKU-2", quantity: 0, active: false },
    { sku: "SKU-3", quantity: 4, active: true }
  ];

  findAvailable(): InventoryItem[] {
    return this.items.filter((item) => item.active && item.quantity > 0);
  }
}
