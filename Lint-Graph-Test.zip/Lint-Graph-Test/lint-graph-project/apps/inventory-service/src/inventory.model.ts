export interface InventoryItem {
  sku: string;
  quantity: number;
  active: boolean;
}
