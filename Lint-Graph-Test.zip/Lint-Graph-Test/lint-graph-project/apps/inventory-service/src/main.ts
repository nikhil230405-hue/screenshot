import { InventoryService } from "./inventory.service";

const service = new InventoryService();
const snapshot = service.getSnapshot();

console.log(snapshot);
