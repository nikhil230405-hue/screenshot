from __future__ import annotations

import msvcrt
from pathlib import Path
from uuid import uuid4

from langgraph.types import Command

from .workflow import build_graph


def read_human_decision() -> str:
    print("\nEnter ACCEPT or REJECT: ", end="", flush=True)

    chars = []

    while True:
        ch = msvcrt.getwch()

        if ch == "\r":
            print()
            return "".join(chars).strip().upper()

        if ch == "\b":
            if chars:
                chars.pop()
                print("\b \b", end="", flush=True)
            continue

        chars.append(ch)
        print(ch, end="", flush=True)


def main() -> int:
    # Repository root = parent directory of the graph/ folder
    repository_root = Path(__file__).resolve().parent.parent

    # Build the LangGraph workflow
    graph = build_graph()

    # Create a unique thread for this graph execution
    thread_id = str(uuid4())

    config = {
        "configurable": {
            "thread_id": thread_id,
        }
    }

    initial_state = {
        "repository_root": str(repository_root),
        "remediation_attempts": 0,
        "retry_count": 0,
        "execution_trace": [],
    }

    print("Starting Lint Harness Graph...")
    print(f"Repository: {repository_root}")
    print(f"Thread ID: {thread_id}")

    result = graph.invoke(
        initial_state,
        config=config,
    )

    while "__interrupt__" in result:
        interrupt_data = result["__interrupt__"]

        print("\nHuman approval required.")
        print(interrupt_data)

        decision = read_human_decision()

        if decision not in {"ACCEPT", "REJECT"}:
            print("Invalid input. Please enter ACCEPT or REJECT.")
            continue

        result = graph.invoke(
            Command(resume=decision),
            config=config,
        )

    print("\nGraph execution completed.")
    print(f"Final status: {result.get('final_status')}")
    print(f"Lint passed: {result.get('lint_passed')}")
    print(f"Remediation attempts: {result.get('remediation_attempts')}")
    print(f"Retry count: {result.get('retry_count')}")

    print("\nExecution trace:")
    for trace_item in result.get("execution_trace", []):
        print(
            f"{trace_item['timestamp']} | "
            f"{trace_item['node']} | "
            f"{trace_item['status']}"
        )

    if result.get("lint_passed", False):
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())