from __future__ import annotations

from .state import LintHarnessState


def route_after_guard(
    state: LintHarnessState,
) -> str:
    if state.get("lint_required", False):
        return "nx"

    return "end"


def route_after_nx(
    state: LintHarnessState,
) -> str:
    if state.get("affected_projects", []):
        return "lint"

    return "end"


def route_after_lint(
    state: LintHarnessState,
) -> str:
    if state.get("lint_passed", False):
        return "end"

    return "failure_analysis"


def route_after_human_approval(
    state: LintHarnessState,
) -> str:
    if state.get("human_approved", False):
        return "stage_changes"

    return "remediation"