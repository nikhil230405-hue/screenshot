from __future__ import annotations

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph

from .nodes import (
    detect_changes_node,
    failure_analysis_node,
    guard_node,
    human_approval_node,
    nx_affected_projects_node,
    remediation_node,
    run_lint_node,
    stage_changes_node,
)

from .routing import (
    route_after_guard,
    route_after_human_approval,
    route_after_lint,
    route_after_nx,
)

from .state import LintHarnessState


def build_graph():
    builder = StateGraph(LintHarnessState)

    # -----------------------------------------------------
    # Register Nodes
    # -----------------------------------------------------

    builder.add_node(
        "detect_changes",
        detect_changes_node,
    )

    builder.add_node(
        "guard",
        guard_node,
    )

    builder.add_node(
        "nx_affected_projects",
        nx_affected_projects_node,
    )

    builder.add_node(
        "run_lint",
        run_lint_node,
    )

    builder.add_node(
        "failure_analysis",
        failure_analysis_node,
    )

    builder.add_node(
        "remediation",
        remediation_node,
    )

    builder.add_node(
        "human_approval",
        human_approval_node,
    )

    builder.add_node(
        "stage_changes",
        stage_changes_node,
    )

    # -----------------------------------------------------
    # START → Detect Changes → Guard
    # -----------------------------------------------------

    builder.add_edge(
        START,
        "detect_changes",
    )

    builder.add_edge(
        "detect_changes",
        "guard",
    )

    # -----------------------------------------------------
    # Guard → Nx or END
    # -----------------------------------------------------

    builder.add_conditional_edges(
        "guard",
        route_after_guard,
        {
            "nx": "nx_affected_projects",
            "end": END,
        },
    )

    # -----------------------------------------------------
    # Nx → Lint or END
    # -----------------------------------------------------

    builder.add_conditional_edges(
        "nx_affected_projects",
        route_after_nx,
        {
            "lint": "run_lint",
            "end": END,
        },
    )

    # -----------------------------------------------------
    # Lint → END or Failure Analysis
    # -----------------------------------------------------

    builder.add_conditional_edges(
        "run_lint",
        route_after_lint,
        {
            "end": END,
            "failure_analysis": "failure_analysis",
        },
    )

    # -----------------------------------------------------
    # Failure Analysis → Remediation
    # -----------------------------------------------------

    builder.add_edge(
        "failure_analysis",
        "remediation",
    )

    # -----------------------------------------------------
    # Remediation → Human Approval
    # -----------------------------------------------------

    builder.add_edge(
        "remediation",
        "human_approval",
    )

    # -----------------------------------------------------
    # Human Approval → Stage or Remediation
    # -----------------------------------------------------

    builder.add_conditional_edges(
        "human_approval",
        route_after_human_approval,
        {
            "stage_changes": "stage_changes",
            "remediation": "remediation",
        },
    )

    # -----------------------------------------------------
    # Stage Changes → Revalidation
    # -----------------------------------------------------
    #
    # Revalidation uses the same validation path again:
    #
    # Guard → Nx → Lint
    #
    # We therefore return to Guard rather than creating
    # duplicate validation nodes.
    # -----------------------------------------------------

    builder.add_edge("stage_changes", "detect_changes")

    # -----------------------------------------------------
    # Checkpoint
    # -----------------------------------------------------

    checkpointer = InMemorySaver()

    return builder.compile(
        checkpointer=checkpointer,
    )