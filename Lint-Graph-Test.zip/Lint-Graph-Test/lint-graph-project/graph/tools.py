from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass


@dataclass
class CommandResult:
    command: list[str]
    exit_code: int
    stdout: str
    stderr: str
    duration_seconds: float


def run_command(
    command: list[str],
    cwd: str,
) -> CommandResult:
    start_time = time.perf_counter()

    result = subprocess.run(
        command,
        cwd=cwd,
        capture_output=True,
        text=True,
        shell=False,
    )

    duration_seconds = time.perf_counter() - start_time

    return CommandResult(
        command=command,
        exit_code=result.returncode,
        stdout=result.stdout,
        stderr=result.stderr,
        duration_seconds=duration_seconds,
    )


def get_staged_files(repository_root: str) -> list[str]:
    result = run_command(
        [
            "git",
            "diff",
            "--cached",
            "--name-only",
            "--diff-filter=ACMR",
        ],
        repository_root,
    )

    if result.exit_code != 0:
        raise RuntimeError(
            "Failed to get staged files.\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    return [
        line.strip()
        for line in result.stdout.splitlines()
        if line.strip()
    ]


def get_affected_lint_projects(
    repository_root: str,
) -> CommandResult:
    return run_command(
        [
            "npx.cmd",
            "nx",
            "show",
            "projects",
            "--affected",
            "--withTarget=lint",
            "--json",
        ],
        repository_root,
    )


def run_affected_lint(
    repository_root: str,
) -> CommandResult:
    return run_command(
        [
            "npm.cmd",
            "run",
            "affected:lint:ci",
        ],
        repository_root,
    )


def stage_all_changes(
    repository_root: str,
) -> CommandResult:
    return run_command(
        [
            "git",
            "add",
            "-A",
        ],
        repository_root,
    )