from __future__ import annotations

from typing import Any, TypedDict


class LintHarnessState(TypedDict, total=False):
    # Repository
    repository_root: str

    # Change detection / guard
    changed_files: list[str]
    lint_relevant_files: list[str]
    lint_required: bool

    # Nx
    affected_projects: list[str]

    # Lint validation
    validation_output: str
    validation_error: str
    validation_exit_code: int
    validation_duration_seconds: float
    lint_passed: bool

    # Failure analysis / artifacts
    failure_log_path: str | None
    failure_history_path: str | None
    prompt_path: str | None
    failure_context: list[dict[str, Any]]

    # Remediation
    remediation_attempts: int
    remediation_completed: bool

    # Human approval
    human_approved: bool | None

    # Retry / final result
    retry_count: int
    final_status: str | None

    # Observability
    execution_trace: list[dict[str, Any]]