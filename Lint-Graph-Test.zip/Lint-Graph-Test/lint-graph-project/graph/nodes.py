from __future__ import annotations

import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from langgraph.types import interrupt

from .state import LintHarnessState
from .tools import (
    get_affected_lint_projects,
    get_staged_files,
    run_affected_lint,
    stage_all_changes,
)


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

LINT_RELEVANT_EXTENSIONS = {
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".html",
}


# ---------------------------------------------------------
# Trace Helper
# ---------------------------------------------------------

def add_trace(
    state: LintHarnessState,
    node: str,
    status: str,
) -> list[dict]:
    trace = list(
        state.get(
            "execution_trace",
            [],
        )
    )

    trace.append(
        {
            "timestamp": datetime.now(
                timezone.utc
            ).isoformat(),
            "node": node,
            "status": status,
        }
    )

    return trace


# ---------------------------------------------------------
# Node 1 - Detect Changes
# ---------------------------------------------------------

def detect_changes_node(
    state: LintHarnessState,
) -> LintHarnessState:
    repository_root = state["repository_root"]

    changed_files = get_staged_files(
        repository_root
    )

    return {
        "changed_files": changed_files,
        "execution_trace": add_trace(
            state,
            "detect_changes",
            "completed",
        ),
    }


# ---------------------------------------------------------
# Node 2 - Guard / Decision
# ---------------------------------------------------------

def guard_node(
    state: LintHarnessState,
) -> LintHarnessState:
    changed_files = state.get(
        "changed_files",
        [],
    )

    lint_relevant_files = [
        file_path
        for file_path in changed_files
        if Path(file_path).suffix.lower()
        in LINT_RELEVANT_EXTENSIONS
    ]

    lint_required = bool(
        lint_relevant_files
    )

    return {
        "lint_relevant_files": lint_relevant_files,
        "lint_required": lint_required,
        "execution_trace": add_trace(
            state,
            "guard",
            "completed",
        ),
    }


# ---------------------------------------------------------
# Node 3 - Nx Affected Project Detection
# ---------------------------------------------------------

def nx_affected_projects_node(
    state: LintHarnessState,
) -> LintHarnessState:
    repository_root = state["repository_root"]

    result = get_affected_lint_projects(
        repository_root
    )

    if result.exit_code != 0:
        raise RuntimeError(
            "Nx affected-project detection failed.\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    raw_output = result.stdout.strip()

    try:
        projects = json.loads(
            raw_output
        )
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "Nx returned invalid JSON.\n"
            f"Output:\n{raw_output}"
        ) from exc

    if not isinstance(
        projects,
        list,
    ):
        raise RuntimeError(
            "Expected Nx output to be a JSON array."
        )

    affected_projects = [
        str(project).strip()
        for project in projects
        if str(project).strip()
    ]

    return {
        "affected_projects": affected_projects,
        "execution_trace": add_trace(
            state,
            "nx_affected_projects",
            "completed",
        ),
    }


# ---------------------------------------------------------
# Node 4 - Run Lint Validation
# ---------------------------------------------------------

def run_lint_node(
    state: LintHarnessState,
) -> LintHarnessState:
    repository_root = state["repository_root"]

    result = run_affected_lint(
        repository_root
    )

    combined_output = result.stdout

    if result.stderr:
        combined_output += (
            "\n" + result.stderr
        )

    return {
        "validation_output": combined_output,
        "validation_error": result.stderr,
        "validation_exit_code": result.exit_code,
        "validation_duration_seconds": (
            result.duration_seconds
        ),
        "lint_passed": (
            result.exit_code == 0
        ),
        "execution_trace": add_trace(
            state,
            "run_lint",
            (
                "passed"
                if result.exit_code == 0
                else "failed"
            ),
        ),
    }


# ---------------------------------------------------------
# Node 5 - Failure Analysis & Log Artifacts
# ---------------------------------------------------------

def failure_analysis_node(
    state: LintHarnessState,
) -> LintHarnessState:
    repository_root = Path(
        state["repository_root"]
    )

    artifacts_dir = (
        repository_root / "artifacts"
    )

    history_dir = (
        artifacts_dir / "history"
    )

    artifacts_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    history_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    validation_output = state.get(
        "validation_output",
        "",
    )

    if not validation_output.strip():
        raise RuntimeError(
            "Failure analysis received empty "
            "validation output."
        )

    timestamp = datetime.now().strftime(
        "%Y%m%d-%H%M%S"
    )

    failure_log_path = (
        artifacts_dir
        / "lint-failure.log"
    )

    history_log_path = (
        history_dir
        / f"failure-{timestamp}.log"
    )

    prompt_path = (
        artifacts_dir
        / "lint-fix-prompt.md"
    )

    # -----------------------------------------------------
    # 1. Preserve complete lint output
    # -----------------------------------------------------

    failure_log_path.write_text(
        validation_output,
        encoding="utf-8",
    )

    history_log_path.write_text(
        validation_output,
        encoding="utf-8",
    )

    # -----------------------------------------------------
    # 2. Extract structured failure information
    # -----------------------------------------------------

    failure_context = parse_lint_failures(
        validation_output
    )

    # -----------------------------------------------------
    # 3. Build remediation prompt
    # -----------------------------------------------------

    remediation_prompt = (
        build_remediation_prompt(
            failure_context
        )
    )

    prompt_path.write_text(
        remediation_prompt,
        encoding="utf-8",
    )

    # -----------------------------------------------------
    # 4. Store compact information in graph state
    # -----------------------------------------------------

    return {
        "failure_log_path": str(
            failure_log_path
        ),
        "failure_history_path": str(
            history_log_path
        ),
        "prompt_path": str(
            prompt_path
        ),
        "failure_context": failure_context,
        "execution_trace": add_trace(
            state,
            "failure_analysis",
            "completed",
        ),
    }


# ---------------------------------------------------------
# Parse Lint Failures
# ---------------------------------------------------------

def parse_lint_failures(
    output: str,
) -> list[dict]:
    failures: list[dict] = []

    current_file: str | None = None

    file_pattern = re.compile(
        r"^(?P<file>[A-Za-z]:[\\/].+)$"
    )

    error_pattern = re.compile(
        r"^\s*"
        r"(?P<line>\d+):"
        r"(?P<column>\d+)"
        r"\s+error\s+"
        r"(?P<message>.+?)"
        r"\s+"
        r"(?P<rule>[A-Za-z0-9_/@.-]+)"
        r"\s*$"
    )

    for raw_line in output.splitlines():

        line = raw_line.rstrip()

        # ---------------------------------------------
        # Detect file-path line
        # ---------------------------------------------

        file_match = file_pattern.match(
            line.strip()
        )

        if file_match:
            current_file = (
                file_match.group(
                    "file"
                ).strip()
            )
            continue

        # ---------------------------------------------
        # Detect lint error line
        # ---------------------------------------------

        error_match = error_pattern.match(
            line
        )

        if not error_match:
            continue

        failures.append(
            {
                "file": current_file,
                "line": int(
                    error_match.group(
                        "line"
                    )
                ),
                "column": int(
                    error_match.group(
                        "column"
                    )
                ),
                "message": (
                    error_match.group(
                        "message"
                    ).strip()
                ),
                "rule": (
                    error_match.group(
                        "rule"
                    ).strip()
                ),
                "severity": "error",
            }
        )

    return failures


# ---------------------------------------------------------
# Build Remediation Prompt
# ---------------------------------------------------------

def build_remediation_prompt(
    failures: list[dict],
) -> str:
    lines = [
        "# Graph Lint Remediation",
        "",
        "You are the remediation agent in a Git pre-commit "
        "quality workflow.",
        "",
        "Your responsibility is to fix the lint failures "
        "provided in the failure context.",
        "",
        "## Remediation Instructions",
        "",
        "1. Review the provided lint failure context and "
        "the attached failure log.",
        "2. Inspect the affected source files before making "
        "changes.",
        "3. Fix all reported lint errors.",
        "4. Preserve the existing application behavior as "
        "much as possible.",
        "5. Do not modify unrelated files or unrelated code.",
        "6. Do not remove, disable, or weaken lint rules just "
        "to make validation pass.",
        "7. Do not ignore or suppress the reported lint "
        "errors unless the existing project configuration "
        "clearly requires it.",
        "8. Review the changes you made and make sure the "
        "reported issues have been addressed.",
        "9. Leave the corrected files in the working tree "
        "for the workflow to review.",
        "10. Do not create a commit.",
        "11. Do not stage the changes.",
        "12. Do not run the commit/retry workflow.",
        "13. Do not make or assume the human approval decision.",
        "14. The Graph workflow will handle human approval, "
        "staging, and revalidation after your remediation.",
        "",
        "## Expected Outcome",
        "",
        "Return control to the Graph workflow with the "
        "corrected files left in the working repository.",
        "",
        "## Lint Failure Context",
        "",
    ]

    if not failures:
        lines.extend(
            [
                "No structured lint failures could be "
                "extracted from the output.",
                "Use the attached failure log as the "
                "source of truth for the reported lint errors.",
                "",
            ]
        )

    for failure in failures:
        lines.extend(
            [
                f"File: {failure.get('file')}",
                f"Line: {failure.get('line')}",
                f"Column: {failure.get('column')}",
                f"Rule: {failure.get('rule')}",
                f"Severity: {failure.get('severity')}",
                f"Message: {failure.get('message')}",
                "",
            ]
        )

    lines.extend(
        [
            "## Important Workflow Boundary",
            "",
            "The Graph, not the remediation agent, controls "
            "the workflow after remediation.",
            "After human approval, the Graph will stage the "
            "changes and run the normal validation again.",
            "If validation fails again, a new failure context "
            "will be provided for another remediation cycle.",
        ]
    )

    return "\n".join(lines)


# ---------------------------------------------------------
# Node 6 - Remediation
# ---------------------------------------------------------

def remediation_node(
    state: LintHarnessState,
) -> LintHarnessState:
    repository_root = state["repository_root"]

    failure_log_path = state.get(
        "failure_log_path"
    )

    prompt_path = state.get(
        "prompt_path"
    )

    if not failure_log_path:
        raise RuntimeError(
            "Failure log path is missing."
        )

    if not prompt_path:
        raise RuntimeError(
            "Remediation prompt path is missing."
        )

    failure_log = Path(
        failure_log_path
    )

    prompt_file = Path(
        prompt_path
    )

    if not failure_log.exists():
        raise RuntimeError(
            f"Failure log does not exist: "
            f"{failure_log}"
        )

    if not prompt_file.exists():
        raise RuntimeError(
            f"Remediation prompt does not exist: "
            f"{prompt_file}"
        )

    prompt = prompt_file.read_text(
        encoding="utf-8"
    ).strip()

    if not prompt:
        raise RuntimeError(
            "Remediation prompt is empty."
        )

    result = subprocess.run(
        [
            "code.cmd",
            "chat",
            "--mode",
            "agent",
            "--add-file",
            str(failure_log),
            "--add-file",
            str(prompt_file),
            prompt,
        ],
        cwd=repository_root,
        capture_output=True,
        text=True,
        shell=False,
    )

    if result.returncode != 0:
        raise RuntimeError(
            "Remediation agent failed.\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    remediation_attempts = (
        state.get(
            "remediation_attempts",
            0,
        )
        + 1
    )

    return {
        "remediation_attempts": (
            remediation_attempts
        ),
        "remediation_completed": True,
        "execution_trace": add_trace(
            state,
            "remediation",
            "completed",
        ),
    }


# ---------------------------------------------------------
# Node 7 - Human Approval
# ---------------------------------------------------------

def human_approval_node(
    state: LintHarnessState,
) -> LintHarnessState:
    decision = interrupt(
        {
            "type": "lint_remediation_approval",
            "message": (
                "Review the remediation changes "
                "and choose ACCEPT or REJECT."
            ),
            "failure_context": state.get(
                "failure_context",
                [],
            ),
            "remediation_attempt": state.get(
                "remediation_attempts",
                0,
            ),
        }
    )

    if not isinstance(
        decision,
        str,
    ):
        raise ValueError(
            "Human decision must be a string."
        )

    decision = decision.strip().upper()

    if decision not in {
        "ACCEPT",
        "REJECT",
    }:
        raise ValueError(
            "Decision must be ACCEPT or REJECT."
        )

    return {
        "human_approved": (
            decision == "ACCEPT"
        ),
        "execution_trace": add_trace(
            state,
            "human_approval",
            decision.lower(),
        ),
    }


# ---------------------------------------------------------
# Node 8 - Stage Changes
# ---------------------------------------------------------

def stage_changes_node(
    state: LintHarnessState,
) -> LintHarnessState:
    repository_root = state["repository_root"]

    result = stage_all_changes(
        repository_root
    )

    if result.exit_code != 0:
        raise RuntimeError(
            "Failed to stage changes.\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    return {
        "execution_trace": add_trace(
            state,
            "stage_changes",
            "completed",
        ),
    }