param(
  [string]$SummaryPath = ".git/sonar-harness/sonar-summary.json",
  [string]$ExplainJsonPath = ".git/sonar-harness/sonar-failure.json",
  [string]$ProjectKey = ""
)

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $repoRoot

$summaryAbsPath = Join-Path $repoRoot $SummaryPath
$explainJsonAbsPath = Join-Path $repoRoot $ExplainJsonPath

function Get-TextValue {
  param($Value)

  if ($null -eq $Value) {
    return $null
  }

  if ($Value -is [string]) {
    return [string]$Value
  }

  if ($Value.PSObject.Properties.Name -contains "text") {
    return [string]$Value.text
  }

  if ($Value.PSObject.Properties.Name -contains "markdown") {
    return [string]$Value.markdown
  }

  return [string]$Value
}

function Strip-RuleMarkup {
  param([string]$Text)

  if ([string]::IsNullOrWhiteSpace($Text)) {
    return $null
  }

  $decoded = [System.Net.WebUtility]::HtmlDecode($Text)
  $withoutTags = [System.Text.RegularExpressions.Regex]::Replace($decoded, "<[^>]+>", " ")
  $collapsed = [System.Text.RegularExpressions.Regex]::Replace($withoutTags, "\s+", " ")
  return $collapsed.Trim()
}

function Get-DescriptionSectionText {
  param(
    $Sections,
    [string]$SectionKey
  )

  if ($null -eq $Sections) {
    return $null
  }

  foreach ($section in @($Sections)) {
    if ($section.key -eq $SectionKey) {
      return Strip-RuleMarkup -Text (Get-TextValue $section.content)
    }
  }

  return $null
}

function New-SonarAuthCandidates {
  param(
    [string]$Token,
    [string]$TokenSource
  )

  if ([string]::IsNullOrWhiteSpace($Token)) {
    return @()
  }

  $normalizedToken = $Token.Trim()
  if ([string]::IsNullOrWhiteSpace($normalizedToken)) {
    return @()
  }

  if ($normalizedToken -eq "YOUR_TOKEN") {
    return @()
  }

  $bytes = [System.Text.Encoding]::ASCII.GetBytes(("{0}:" -f $normalizedToken))
  $base64 = [Convert]::ToBase64String($bytes)

  return @(
    [pscustomobject]@{
      headers = @{ Authorization = "Basic $base64" }
      authMode = "basic"
      tokenSource = $TokenSource
    },
    [pscustomobject]@{
      headers = @{ Authorization = "Bearer $normalizedToken" }
      authMode = "bearer"
      tokenSource = $TokenSource
    }
  )
}

function Invoke-SonarApi {
  param(
    [string]$BaseUrl,
    [string]$RelativePath,
    [hashtable]$Headers
  )

  $normalizedBase = $BaseUrl.TrimEnd("/")
  $uri = "$normalizedBase$RelativePath"
  return Invoke-RestMethod -Method Get -Uri $uri -Headers $Headers -TimeoutSec 20
}

function Get-ScopedEnvValue {
  param([string]$Name)

  $processValue = [Environment]::GetEnvironmentVariable($Name, "Process")
  if (-not [string]::IsNullOrWhiteSpace($processValue)) {
    return $processValue
  }

  $userValue = [Environment]::GetEnvironmentVariable($Name, "User")
  if (-not [string]::IsNullOrWhiteSpace($userValue)) {
    return $userValue
  }

  $machineValue = [Environment]::GetEnvironmentVariable($Name, "Machine")
  if (-not [string]::IsNullOrWhiteSpace($machineValue)) {
    return $machineValue
  }

  return $null
}

function Get-ScopedTokenCandidates {
  $tokenScopes = @(
    [pscustomobject]@{ source = "process"; value = [Environment]::GetEnvironmentVariable("SONAR_TOKEN", "Process") },
    [pscustomobject]@{ source = "user"; value = [Environment]::GetEnvironmentVariable("SONAR_TOKEN", "User") },
    [pscustomobject]@{ source = "machine"; value = [Environment]::GetEnvironmentVariable("SONAR_TOKEN", "Machine") }
  )

  $candidates = New-Object System.Collections.Generic.List[object]
  $seenTokenValues = New-Object System.Collections.Generic.HashSet[string]

  foreach ($scope in $tokenScopes) {
    if ([string]::IsNullOrWhiteSpace($scope.value)) {
      continue
    }

    $tokenValue = $scope.value.Trim()
    if ([string]::IsNullOrWhiteSpace($tokenValue) -or $tokenValue -eq "YOUR_TOKEN") {
      continue
    }

    if ($seenTokenValues.Add($tokenValue)) {
      foreach ($auth in (New-SonarAuthCandidates -Token $tokenValue -TokenSource $scope.source)) {
        $candidates.Add($auth) | Out-Null
      }
    }
  }

  return $candidates
}

function Get-RuleCandidates {
  param([string]$RuleId)

  return @("csharpsquid:$RuleId", "csharp:$RuleId")
}

function Get-RuleMetadata {
  param(
    [string]$RuleId,
    [string]$BaseUrl,
    $AuthCandidates
  )

  $candidateKeys = Get-RuleCandidates -RuleId $RuleId
  $searchErrors = New-Object System.Collections.Generic.List[string]
  $resolvedAuthCandidates = @($AuthCandidates)

  if (-not [string]::IsNullOrWhiteSpace($BaseUrl) -and $resolvedAuthCandidates.Count -gt 0) {
    foreach ($candidateKey in $candidateKeys) {
      foreach ($auth in $resolvedAuthCandidates) {
        try {
          $ruleResponse = Invoke-SonarApi -BaseUrl $BaseUrl -RelativePath "/api/rules/show?key=$([System.Uri]::EscapeDataString($candidateKey))" -Headers $auth.headers
          if ($ruleResponse.rule) {
            $desc = Strip-RuleMarkup -Text (Get-TextValue $ruleResponse.rule.htmlDesc)
            if ([string]::IsNullOrWhiteSpace($desc)) {
              $desc = Strip-RuleMarkup -Text (Get-TextValue $ruleResponse.rule.mdDesc)
            }

            $rootCauseText = Get-DescriptionSectionText -Sections $ruleResponse.rule.descriptionSections -SectionKey "root_cause"
            $howToFixText = Get-DescriptionSectionText -Sections $ruleResponse.rule.descriptionSections -SectionKey "how_to_fix"
            if ([string]::IsNullOrWhiteSpace($desc)) {
              $desc = $rootCauseText
            }

            return [pscustomobject]@{
              source = "sonarqube-api/$($auth.authMode)/$($auth.tokenSource)"
              lookupKey = $candidateKey
              title = if ($ruleResponse.rule.name) { [string]$ruleResponse.rule.name } else { $null }
              explanation = if ($desc) { $desc } else { $null }
              rootCause = if ($rootCauseText) { $rootCauseText } else { $null }
              fixStrategy = if ($howToFixText) { $howToFixText } else { $null }
              severity = [string]$ruleResponse.rule.severity
              type = [string]$ruleResponse.rule.type
              tags = @($ruleResponse.rule.tags)
            }
          }
        }
        catch {
          $searchErrors.Add(("{0} ({1}/{2}): {3}" -f $candidateKey, $auth.authMode, $auth.tokenSource, $_.Exception.Message)) | Out-Null
        }
      }
    }
  }

  return [pscustomobject]@{
    source = "unavailable"
    lookupKey = $candidateKeys[0]
    title = $null
    explanation = $null
    rootCause = $null
    fixStrategy = $null
    severity = $null
    type = $null
    tags = @()
    apiErrors = @($searchErrors)
  }
}

if (-not (Test-Path $summaryAbsPath)) {
  throw "Summary file not found: $summaryAbsPath"
}

$summary = Get-Content -Path $summaryAbsPath -Raw | ConvertFrom-Json
$baseUrl = Get-ScopedEnvValue -Name "SONAR_HOST_URL"
if ([string]::IsNullOrWhiteSpace($ProjectKey)) {
  $ProjectKey = Get-ScopedEnvValue -Name "SONAR_PROJECT_KEY"
}
$authCandidates = Get-ScopedTokenCandidates

if (-not [string]::IsNullOrWhiteSpace($baseUrl)) {
  $baseUrl = $baseUrl.Trim()
}
if (-not [string]::IsNullOrWhiteSpace($ProjectKey)) {
  $ProjectKey = $ProjectKey.Trim()
}

$apiConfigured = (-not [string]::IsNullOrWhiteSpace($baseUrl) -and @($authCandidates).Count -gt 0)

$blockedIssues = @($summary.blockedIssues)
$enrichedIssues = New-Object System.Collections.Generic.List[object]
$ruleMetadataCache = @{}
$cacheHits = 0
$cacheMisses = 0

foreach ($issue in $blockedIssues) {
  $ruleId = [string]$issue.ruleId
  $cacheKey = $ruleId.ToUpperInvariant()

  if ($ruleMetadataCache.ContainsKey($cacheKey)) {
    $metadata = $ruleMetadataCache[$cacheKey]
    $cacheHits++
  }
  else {
    $metadata = Get-RuleMetadata -RuleId $ruleId -BaseUrl $baseUrl -AuthCandidates @($authCandidates)
    $ruleMetadataCache[$cacheKey] = $metadata
    $cacheMisses++
  }

  $enrichedIssues.Add([pscustomobject]@{
    ruleId = $ruleId
    line = ("{0}:{1}" -f $issue.file, $issue.line)
    level = [string]$issue.level
    rootCause = [string]$metadata.rootCause
    fixStrategy = [string]$metadata.fixStrategy
    severity = [string]$metadata.severity
  }) | Out-Null
}

$explainData = [ordered]@{
  generatedAtUtc = [DateTime]::UtcNow.ToString("o")
  issues = @($enrichedIssues | ForEach-Object { $_ })
}

$explain = [pscustomobject]$explainData

$explain | ConvertTo-Json -Depth 20 | Set-Content -Path $explainJsonAbsPath -Encoding utf8

Write-Host "[sonar-enrich] Wrote $explainJsonAbsPath"