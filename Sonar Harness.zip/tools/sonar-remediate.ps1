param(
  [string]$ExplainPath = ".git/sonar-harness/sonar-failure.json",
  [string]$CopilotRoot = ".git/sonar-harness",
  [switch]$NoLaunch
)

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $repoRoot

$explainAbsPath = Join-Path $repoRoot $ExplainPath
$copilotRootAbsPath = Join-Path $repoRoot $CopilotRoot
$historyDir = Join-Path $copilotRootAbsPath "history"
$latestPromptPath = Join-Path $copilotRootAbsPath "sonar-fix-prompt.md"

function Get-GitPath {
  param([Parameter(Mandatory = $true)][string]$RelativePath)

  $resolvedPath = (& git rev-parse --git-path $RelativePath)
  if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($resolvedPath)) {
    throw "Failed to resolve git path for '$RelativePath'."
  }

  if ([System.IO.Path]::IsPathRooted($resolvedPath)) {
    return $resolvedPath.Trim()
  }

  return Join-Path $repoRoot $resolvedPath.Trim()
}

function Ensure-Folders {
  New-Item -ItemType Directory -Force -Path $copilotRootAbsPath | Out-Null
  New-Item -ItemType Directory -Force -Path $historyDir | Out-Null
}

function Get-Timestamp {
  return ((Get-Date).ToString("o") -replace "[\.:]", "-")
}

function New-RemediationPrompt {
  param([string]$ProceedCommand)

  return @(
    "Copilot Autofix Request (Sonar Pre-Commit)"
    ""
    "Strict workflow requirements (do not skip any step):"
    ""
    "1. Read the attached sonar-failure.json which contains the complete issue list with all necessary Sonar metadata."
    "2. Review every reported Sonar issue before changing code."
    "3. Use the supplied Sonar metadata to understand why each issue exists before deciding on a fix."
    "4. Fix all reported Sonar issues directly in the files (make actual code changes)."
    "5. Preserve behavior, formatting, and existing style of the code."
    "6. Avoid unrelated refactoring."
    "7. Do not modify files that have no reported issues."
    "8. Fix multiple issues in the same file together whenever possible."
    "9. After implementing all fixes, show all proposed changes to the user for review."
    "10. After the user reviews the changes, open an interactive confirmation question using vscode_askQuestions."
    "11. The question header must be: sonar_fix_confirmation"
    "12. The question text must ask whether the user accepts the implemented Sonar fixes and wants to proceed to validation."
    "13. Provide exactly two options: ACCEPT_AND_PROCEED, REJECT_AND_RETRY"
    "14. Set allowFreeformInput to false."
    "15. If the user selects REJECT_AND_RETRY, discard the current changes and retry fixing the issues (restart from step 1 with the same sonar-failure.json)."
    "16. If the user selects ACCEPT_AND_PROCEED, YOU must run this command yourself:"
    ""
    ("    {0}" -f $ProceedCommand)
    ""
    "17. Do not ask the user to run the command manually. Execute it using your terminal tool."
    "18. That proceed command stages all the changes you made, reruns the analyzer gate, and if validation passes executes a normal git commit with a fixed remediation message so pre-commit hooks run again."
    "19. If that follow-up git commit fails, inspect the refreshed Sonar artifacts, continue remediation in the same Agent session, and ask again later."
    "20. Do not call Sonar APIs. Phase 2 already enriched the required metadata."
  ) -join [Environment]::NewLine
}

function Write-PromptHistory {
  param([string]$PromptText)

  $timestamp = Get-Timestamp
  $historyPromptPath = Join-Path $historyDir ("sonar-fix-prompt-{0}.md" -f $timestamp)

  $PromptText | Set-Content -LiteralPath $latestPromptPath -Encoding utf8
  $PromptText | Set-Content -LiteralPath $historyPromptPath -Encoding utf8

  return [pscustomobject]@{
    LatestPrompt = $latestPromptPath
    HistoryPrompt = $historyPromptPath
  }
}

Ensure-Folders

if (-not (Test-Path -LiteralPath $explainAbsPath)) {
  throw "Explain file not found: $explainAbsPath"
}

$explain = Get-Content -LiteralPath $explainAbsPath -Raw | ConvertFrom-Json
$issueCount = @($explain.issues).Count

if ($issueCount -eq 0) {
  throw "No Sonar issues found in sonar-failure.json."
}

$proceedCommand = "powershell -NoProfile -ExecutionPolicy Bypass -File ./tools/sonar-remediation-proceed.ps1"
$promptText = New-RemediationPrompt -ProceedCommand $proceedCommand

$files = Write-PromptHistory -PromptText $promptText

Write-Host ""
Write-Host "============================================================"
Write-Host "SONAR REMEDIATION AGENT WORKFLOW"
Write-Host "============================================================"
Write-Host ""
Write-Host "Copilot Agent will:"
Write-Host "1. Read sonar-failure.json which contains the complete issue list with all necessary Sonar metadata."
Write-Host "2. Review every Sonar issue and use the supplied metadata before changing code."
Write-Host "3. Fix all reported Sonar issues while preserving behavior and formatting."
Write-Host "4. Avoid unrelated refactoring and only touch files that contain reported issues."
Write-Host "5. Ask for user approval with exactly two options: ACCEPT_AND_PROCEED or REJECT_AND_RETRY."
Write-Host ("6. On ACCEPT_AND_PROCEED, Copilot must run: {0}" -f $proceedCommand)
Write-Host "7. Copilot must not ask the user to run validation manually."
Write-Host "8. If validation passes and commit restart is supported, a new normal git commit will be launched automatically with a fixed remediation message."
Write-Host "9. That follow-up commit invokes the pre-commit hook again, so the remediation loop continues until the staged changes pass."
Write-Host ""
Write-Host ("Explain file: {0}" -f $explainAbsPath)
Write-Host ("Prompt file: {0}" -f $files.LatestPrompt)

Write-Host "============================================================"
Write-Host ""

if ($NoLaunch) {
  Write-Host "[sonar-remediate] NoLaunch specified. Prompt file was generated, but Copilot Chat was not opened."
  exit 0
}

if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
  throw "VS Code command line 'code' was not found in PATH."
}

$chatArgs = @(
  "chat"
  "--mode"
  "agent"
  "--reuse-window"
)

$chatArgs += @("--add-file", $explainAbsPath)
$chatArgs += @("--add-file", $files.LatestPrompt)
$chatArgs += $promptText

& code @chatArgs | Out-Null

Write-Host "[sonar-remediate] Copilot Agent workflow opened. Continue remediation in the Agent session."
exit 0