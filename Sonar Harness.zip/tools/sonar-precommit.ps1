param(
  [string]$Configuration = "Release",
  [bool]$NoRestore = $true
)

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $repoRoot

$artifactDir = Join-Path $repoRoot ".git\sonar-harness"
New-Item -ItemType Directory -Path $artifactDir -Force | Out-Null

function Normalize-Path {
  param([string]$PathValue)

  try {
    return (Resolve-Path -Path $PathValue -ErrorAction Stop).Path.ToLowerInvariant()
  }
  catch {
    return [System.IO.Path]::GetFullPath($PathValue).ToLowerInvariant()
  }
}

function Resolve-SarifUriToAbsPath {
  param(
    [string]$Uri,
    [string]$RepoRoot
  )

  if ([string]::IsNullOrWhiteSpace($Uri)) {
    return $null
  }

  if ($Uri.StartsWith("file:///", [System.StringComparison]::OrdinalIgnoreCase)) {
    try {
      $fileUri = [System.Uri]$Uri
      return Normalize-Path -PathValue $fileUri.LocalPath
    }
    catch {
      return $null
    }
  }

  $relativePath = $Uri.Replace("/", "\")
  return Normalize-Path -PathValue (Join-Path $RepoRoot $relativePath)
}

Write-Host "[sonar-precommit] Detecting staged C# files..."
$stagedFiles = git diff --cached --name-only --diff-filter=ACMR
if ($LASTEXITCODE -ne 0) {
  throw "Failed to read staged files from git."
}

$stagedCsRel = @($stagedFiles | Where-Object { $_ -match "\.cs$" })
if ($stagedCsRel.Count -eq 0) {
  Write-Host "[sonar-precommit] No staged C# files. Skipping analyzer gate."
  exit 0
}

$stagedCsAbsLookup = @{}
foreach ($relPath in $stagedCsRel) {
  $absPath = Normalize-Path -PathValue (Join-Path $repoRoot $relPath)
  $stagedCsAbsLookup[$absPath] = $relPath.Replace("\", "/")
}

$projectSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$unmappedFiles = New-Object System.Collections.Generic.List[string]
$repoRootNormalized = Normalize-Path -PathValue $repoRoot

foreach ($relPath in $stagedCsRel) {
  $currentDir = Split-Path -Parent (Join-Path $repoRoot $relPath)
  $foundProject = $null

  while ($true) {
    $projectInDir = Get-ChildItem -Path $currentDir -Filter "*.csproj" -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($projectInDir) {
      $foundProject = $projectInDir.FullName
      break
    }

    $currentDirNormalized = Normalize-Path -PathValue $currentDir
    if ($currentDirNormalized -eq $repoRootNormalized) {
      break
    }

    $parentDir = Split-Path -Parent $currentDir
    if ([string]::IsNullOrWhiteSpace($parentDir) -or $parentDir -eq $currentDir) {
      break
    }

    $currentDir = $parentDir
  }

  if ($foundProject) {
    [void]$projectSet.Add($foundProject)
  }
  else {
    $unmappedFiles.Add($relPath)
  }
}

if ($unmappedFiles.Count -gt 0) {
  Write-Host "[sonar-precommit] Warning: no .csproj found for staged files:"
  $unmappedFiles | ForEach-Object { Write-Host "  - $_" }
}

$projectList = @($projectSet)
if ($projectList.Count -eq 0) {
  Write-Host "[sonar-precommit] No affected projects found. Skipping analyzer gate."
  exit 0
}

Write-Host "[sonar-precommit] Analyzing $($projectList.Count) affected project(s)..."

$sarifFiles = New-Object System.Collections.Generic.List[string]
$buildFailed = $false
$failedProjects = New-Object System.Collections.Generic.List[string]

foreach ($projectPath in $projectList) {
  $projectName = [System.IO.Path]::GetFileNameWithoutExtension($projectPath)
  $sarifPath = Join-Path $artifactDir ("{0}.sarif" -f $projectName)

  if (Test-Path $sarifPath) {
    Remove-Item -Path $sarifPath -Force
  }

  Write-Host "[sonar-precommit] dotnet build $projectName"
  $buildArgs = @(
    "build"
    $projectPath
    "-c"
    $Configuration
    "-nologo"
    "-v"
    "minimal"
    "-p:RunAnalyzers=true"
    "-p:ErrorLog=$sarifPath"
  )

  if ($NoRestore) {
    $buildArgs += "--no-restore"
  }

  & dotnet @buildArgs
  if ($LASTEXITCODE -ne 0) {
    $buildFailed = $true
    $failedProjects.Add($projectName) | Out-Null
    Write-Host "[sonar-precommit] Build failed for $projectName."
  }

  if (Test-Path $sarifPath) {
    $sarifFiles.Add($sarifPath)
  }
}

if ($sarifFiles.Count -eq 0) {
  if ($buildFailed) {
    Write-Error "[sonar-precommit] Build failed and no SARIF output was generated. Commit blocked."
    exit 1
  }

  Write-Host "[sonar-precommit] No SARIF output generated."
  exit 0
}

$mergedSarif = [ordered]@{
  '$schema' = "https://json.schemastore.org/sarif-2.1.0.json"
  version = "2.1.0"
  runs = @()
}

foreach ($sarifFile in $sarifFiles) {
  $sarifContent = Get-Content -Path $sarifFile -Raw | ConvertFrom-Json
  if ($sarifContent.runs) {
    $mergedSarif.runs += @($sarifContent.runs)
  }
}

$mergedSarifPath = Join-Path $artifactDir "merged.sarif"
$mergedSarif | ConvertTo-Json -Depth 100 | Set-Content -Path $mergedSarifPath -Encoding utf8

foreach ($sarifFile in $sarifFiles) {
  if (Test-Path $sarifFile) {
    Remove-Item -Path $sarifFile -Force -ErrorAction SilentlyContinue
  }
}

$blockedFindings = New-Object System.Collections.Generic.List[object]

foreach ($run in $mergedSarif.runs) {
  if (-not $run.results) {
    continue
  }

  foreach ($result in $run.results) {
    $ruleId = [string]$result.ruleId
    if (-not $ruleId.StartsWith("S", [System.StringComparison]::OrdinalIgnoreCase)) {
      continue
    }

    $level = ([string]$result.level).ToLowerInvariant()
    if ($level -ne "error") {
      continue
    }

    $location = $result.locations | Select-Object -First 1
    if (-not $location) {
      continue
    }

    $uri = $null
    $line = $null

    if ($location.physicalLocation -and $location.physicalLocation.artifactLocation) {
      $uri = [string]$location.physicalLocation.artifactLocation.uri
      $line = $location.physicalLocation.region.startLine
    }
    elseif ($location.resultFile) {
      $uri = [string]$location.resultFile.uri
      $line = $location.resultFile.region.startLine
    }

    if ([string]::IsNullOrWhiteSpace($uri)) {
      continue
    }

    $absPath = Resolve-SarifUriToAbsPath -Uri $uri -RepoRoot $repoRoot
    if (-not $absPath -or -not $stagedCsAbsLookup.ContainsKey($absPath)) {
      continue
    }

    $message = $null
    if ($result.message -is [string]) {
      $message = [string]$result.message
    }
    else {
      $message = [string]$result.message.text
      if ([string]::IsNullOrWhiteSpace($message)) {
        $message = [string]$result.message.markdown
      }
    }

    $blockedFindings.Add([ordered]@{
      ruleId = $ruleId
      level = $level
      file = $stagedCsAbsLookup[$absPath]
      line = $line
      message = $message
    })
  }
}

$summary = [pscustomobject]@{
  generatedAtUtc = [DateTime]::UtcNow.ToString("o")
  stagedCsFileCount = $stagedCsRel.Count
  affectedProjectCount = $projectList.Count
  blockedIssueCount = $blockedFindings.Count
  buildFailedProjectCount = $failedProjects.Count
  buildFailedProjects = @($failedProjects)
  artifacts = [pscustomobject]@{
    mergedSarif = $mergedSarifPath
  }
  blockedIssues = @($blockedFindings | ForEach-Object { $_ })
}

$summaryJsonPath = Join-Path $artifactDir "sonar-summary.json"

$summary | ConvertTo-Json -Depth 20 | Set-Content -Path $summaryJsonPath -Encoding utf8

if ($blockedFindings.Count -gt 0) {
  Write-Host "[sonar-precommit] Found $($blockedFindings.Count) blocking Sonar issue(s) in staged files."
  Write-Host "[sonar-precommit] See: $summaryJsonPath"
  exit 1
}

if ($buildFailed) {
  Write-Host "[sonar-precommit] Build failed for one or more affected projects. Commit blocked."
  Write-Host "[sonar-precommit] See: $summaryJsonPath"
  exit 1
}

Write-Host "[sonar-precommit] No blocking Sonar issues found in staged files."
Write-Host "[sonar-precommit] See: $summaryJsonPath"
exit 0
