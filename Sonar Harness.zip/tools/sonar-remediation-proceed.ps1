param()

$ErrorActionPreference = "Stop"

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $repoRoot
$followUpCommitMessage = "adding new changes after resolving sonar voilations"

function Invoke-CommandCapture {
  param([Parameter(Mandatory = $true)][string]$Command)

  $startInfo = New-Object System.Diagnostics.ProcessStartInfo
  $startInfo.FileName = "cmd.exe"
  $startInfo.Arguments = "/d /s /c $Command"
  $startInfo.WorkingDirectory = $repoRoot
  $startInfo.UseShellExecute = $false
  $startInfo.RedirectStandardOutput = $true
  $startInfo.RedirectStandardError = $true

  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $startInfo
  [void]$process.Start()
  $stdout = $process.StandardOutput.ReadToEnd()
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()

  return [pscustomobject]@{
    Status = $process.ExitCode
    Stdout = $stdout
    Stderr = $stderr
  }
}

function Invoke-ProcessCapture {
  param(
    [Parameter(Mandatory = $true)][string]$FileName,
    [string[]]$Arguments = @()
  )

  $startInfo = New-Object System.Diagnostics.ProcessStartInfo
  $startInfo.FileName = $FileName
  $startInfo.WorkingDirectory = $repoRoot
  $startInfo.UseShellExecute = $false
  $startInfo.RedirectStandardOutput = $true
  $startInfo.RedirectStandardError = $true

  if ($Arguments.Count -gt 0) {
    $quotedArguments = foreach ($argument in $Arguments) {
      if ($null -eq $argument) {
        '""'
        continue
      }

      $argumentText = [string]$argument
      if ($argumentText -match '[\s"]') {
        '"{0}"' -f ($argumentText -replace '"', '\"')
      }
      else {
        $argumentText
      }
    }

    $startInfo.Arguments = ($quotedArguments -join ' ')
  }

  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $startInfo
  [void]$process.Start()
  $stdout = $process.StandardOutput.ReadToEnd()
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()

  return [pscustomobject]@{
    Status = $process.ExitCode
    Stdout = $stdout
    Stderr = $stderr
  }
}

function Invoke-CommitRestart {
  Write-Host ""
  Write-Host "===== Committing the staged changes ====="
  $escapedMessage = $followUpCommitMessage -replace '"', '\"'
  $commitResult = Invoke-CommandCapture -Command ("git commit -m `"{0}`"" -f $escapedMessage)

  if (-not [string]::IsNullOrWhiteSpace($commitResult.Stdout)) {
    Write-Host $commitResult.Stdout
  }

  if (-not [string]::IsNullOrWhiteSpace($commitResult.Stderr)) {
    [Console]::Error.WriteLine($commitResult.Stderr)
  }

  if ($commitResult.Status -ne 0) {
    [Console]::Error.WriteLine("Automatic commit restart failed. The follow-up git commit re-ran hooks and did not complete.")
    return $commitResult.Status
  }

  return 0
}

Write-Host ""
Write-Host "===== Staging Copilot changes after remediation ====="
$stageResult = Invoke-CommandCapture -Command "git add -A"
if (-not [string]::IsNullOrWhiteSpace($stageResult.Stdout)) {
  Write-Host $stageResult.Stdout
}
if (-not [string]::IsNullOrWhiteSpace($stageResult.Stderr)) {
  [Console]::Error.WriteLine($stageResult.Stderr)
}
if ($stageResult.Status -ne 0) {
  [Console]::Error.WriteLine("Failed to stage Copilot changes after remediation.")
  exit $stageResult.Status
}

Write-Host ""
Write-Host "Staging complete. Starting follow-up commit so hooks run via git commit."
$commitRestartStatus = Invoke-CommitRestart
exit $commitRestartStatus