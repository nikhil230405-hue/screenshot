# gnhf run: run-npm-run-affected-d04498

Objective: see .gnhf/runs/run-npm-run-affected-d04498/prompt.md

## Iteration Log

### Iteration 1

**Summary:** [ERROR] copilot exited with code 1: error: Invalid command format.

It looks like your prompt was not quoted, so the extra words were treated as separate arguments.
Wrap the prompt in quotes, for example: copilot -p "your prompt here"

Try 'copilot --help' for more information.



### Iteration 2

**Summary:** [ERROR] copilot exited with code 1: error: Invalid command format.

It looks like your prompt was not quoted, so the extra words were treated as separate arguments.
Wrap the prompt in quotes, for example: copilot -p "your prompt here"

Try 'copilot --help' for more information.


