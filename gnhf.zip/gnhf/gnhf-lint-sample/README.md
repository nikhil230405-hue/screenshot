# GNHF Lint Remediation Sample

Small Nx-style workspace intentionally seeded with ESLint failures for the first GNHF experiment.

## Baseline
Run:

```bash
npm install
npm run affected:lint:ci
```

The `affected:lint:ci` script intentionally runs lint for all five projects so the baseline is deterministic on a fresh checkout.

Expected starting state: lint failures in inventory-service, order-service, user-service, and shared; config should pass.

## Goal for GNHF
Ask the coding agent to fix all lint issues while keeping unrelated files unchanged, and stop when:

```text
npm run affected:lint:ci passes with exit code 0
```
