function inventoryCount(items) {
  if (items.length > 0) {
    return items.length;
  }
  return 0;
}

function findItem(id, items) {
  return items.find((item) => item.id === id);
}

function formatItem(item) {
  const name = item.name;
  return name;
}

module.exports = { inventoryCount, findItem, formatItem };
