function createOrder(items) {
  if (items.length === 0) {
    return null;
  }
  return { items };
}

function calculateTotal(items) {
  return items.reduce((sum, item) => sum + item.price, 0);
}

function getOrderName(order) {
  return order.name;
}

module.exports = { createOrder, calculateTotal, getOrderName };
