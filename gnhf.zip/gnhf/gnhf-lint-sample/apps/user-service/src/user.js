function createUser(user) {
  if (user.name === null || user.name === undefined) {
    return null;
  }
  return {
    id: user.id,
    name: user.name
  };
}

function getDisplayName(user) {
  return user.name;
}

module.exports = { createUser, getDisplayName };
