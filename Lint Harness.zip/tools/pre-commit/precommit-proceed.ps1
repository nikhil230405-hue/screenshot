param()

$ErrorActionPreference = 'Stop'
$commitMessage = 'chore: adding new changes after fixing lint issues'

Write-Host ''
Write-Host '===== Staging changes ====='
& git add -A
if ($LASTEXITCODE -ne 0) {
    [Console]::Error.WriteLine('Failed to stage changes.')
    exit 1
}

& git diff --cached --quiet
if ($LASTEXITCODE -eq 0) {
    [Console]::Error.WriteLine('No staged changes found after autofix. Nothing to commit.')
    exit 1
}

Write-Host ''
Write-Host '===== Creating commit (pre-commit hook will run lint) ====='
Write-Host ('Commit message: "{0}"' -f $commitMessage)
& git commit -m $commitMessage
if ($LASTEXITCODE -ne 0) {
    [Console]::Error.WriteLine('Failed to create commit. Resolve issues above and retry.')
    exit 1
}

Write-Host ''
Write-Host 'Lint-fix commit created successfully.'
Write-Host ''
Write-Host 'You can continue with your normal git workflow.'
exit 0