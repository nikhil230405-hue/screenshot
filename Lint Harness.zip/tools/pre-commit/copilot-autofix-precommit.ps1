param(
    [string]$PromptFile,
    [string]$LogFile
)

$ErrorActionPreference = 'Stop'

if (-not $PromptFile -or -not (Test-Path -LiteralPath $PromptFile)) {
    Write-Error "Prompt file not found: $PromptFile"
}

if (-not $LogFile -or -not (Test-Path -LiteralPath $LogFile)) {
    Write-Error "Failure log file not found: $LogFile"
}

$promptText = Get-Content -LiteralPath $PromptFile -Raw
if ([string]::IsNullOrWhiteSpace($promptText)) {
    $promptText = "Fix lint failures described in the attached log file."
}

Write-Host "Opening Copilot Chat in agent mode with failure context..."
Write-Host ""
Write-Host "============================================================"
Write-Host "PRE-COMMIT LINT FIX WORKFLOW"
Write-Host "============================================================"
Write-Host ""
Write-Host "Copilot will:"
Write-Host "1. Review the lint failures from the attached log"
Write-Host "2. Fix all the lint issues in the code"
Write-Host "3. Ask for user approval to review the changes"
Write-Host "4. Open an interactive option question for acceptance"
Write-Host "5. Options should be: ACCEPT_AND_PROCEED or REJECT_AND_REWORK"
Write-Host "6. On ACCEPT_AND_PROCEED, Copilot must run: powershell -NoProfile -ExecutionPolicy Bypass -File ./tools/pre-commit/precommit-proceed.ps1"
Write-Host "7. Copilot should not ask the user to run this command manually"
Write-Host "8. The new commit will run pre-commit lint automatically"
Write-Host ""
Write-Host "Then continue with the normal git workflow"
Write-Host "============================================================"
Write-Host ""

code chat --mode agent --reuse-window --add-file "$LogFile" --add-file "$PromptFile" "$promptText" | Out-Null