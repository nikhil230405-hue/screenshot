param()

$ErrorActionPreference = 'Stop'

$repoRoot = (Get-Location).Path
$logRoot = Join-Path $repoRoot '.git\lint-harness'
$historyDir = Join-Path $logRoot 'history'
$latestLog = Join-Path $logRoot 'lint-failure.log'
$latestPrompt = Join-Path $logRoot 'lint-fix-prompt.md'

$checkCommand = 'npm run affected:lint:ci'
$detectAffectedLintCommand = 'npx nx show projects --affected --withTarget=lint --json'
$lintRelevantExtensions = '.ts,.tsx,.js,.jsx,.html'

$lintRelevantExtensions = $lintRelevantExtensions.Split(',') |
ForEach-Object { $_.Trim().ToLowerInvariant() } |
Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

function Ensure-Folders {
New-Item -ItemType Directory -Force -Path $historyDir | Out-Null
}

function Invoke-CommandCapture {
param(
[Parameter(Mandatory = $true)][string]$Command,
[hashtable]$ExtraEnv = @{}
)

$savedEnv = @{}
foreach ($entry in $ExtraEnv.GetEnumerator()) {
$name = [string]$entry.Key
$savedEnv[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
[Environment]::SetEnvironmentVariable($name, [string]$entry.Value, 'Process')
}

try {
$startInfo = New-Object System.Diagnostics.ProcessStartInfo
$startInfo.FileName = 'cmd.exe'
$startInfo.Arguments = "/d /s /c $Command"
$startInfo.WorkingDirectory = $repoRoot
$startInfo.UseShellExecute = $false
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $true

foreach ($entry in $ExtraEnv.GetEnumerator()) {
$startInfo.Environment[[string]$entry.Key] = [string]$entry.Value
}

$process = New-Object System.Diagnostics.Process
$process.StartInfo = $startInfo

[void]$process.Start()
$stdout = $process.StandardOutput.ReadToEnd()
$stderr = $process.StandardError.ReadToEnd()
$process.WaitForExit()

return [pscustomobject]@{
Status = $process.ExitCode
Stdout = $stdout
Stderr = $stderr
}
}
finally {
foreach ($entry in $savedEnv.GetEnumerator()) {
[Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, 'Process')
}
}
}

function Invoke-CommandWithLiveOutput {
param(
[Parameter(Mandatory = $true)][string]$Command,
[hashtable]$ExtraEnv = @{}
)

$result = Invoke-CommandCapture -Command $Command -ExtraEnv $ExtraEnv

if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
Write-Host $result.Stdout
}
if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
[Console]::Error.WriteLine($result.Stderr)
}

return $result
}

function Should-CheckAffectedLint {
return [regex]::IsMatch($checkCommand, 'affected:lint')
}

function Get-StagedFiles {
$result = Invoke-CommandCapture -Command 'git diff --cached --name-only --diff-filter=ACMR'
if ($result.Status -ne 0) {
Write-Warning 'Could not read staged files. Continuing with lint checks.'
if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
[Console]::Error.WriteLine($result.Stdout)
}
if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
[Console]::Error.WriteLine($result.Stderr)
}
return $null
}

return ($result.Stdout -split "`r?`n" |
ForEach-Object { $_.Trim() } |
Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}

function Test-HasLintRelevantStagedChanges {
$stagedFiles = Get-StagedFiles
if ($null -eq $stagedFiles) {
return $true
}

foreach ($file in $stagedFiles) {
$lower = $file.ToLowerInvariant()
foreach ($ext in $lintRelevantExtensions) {
if ($lower.EndsWith($ext)) {
return $true
}
}
}

return $false
}

function Get-AffectedLintProjects {
$result = Invoke-CommandCapture -Command $detectAffectedLintCommand
if ($result.Status -ne 0) {
Write-Warning 'Could not detect affected lint projects. Continuing with lint checks.'
if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
[Console]::Error.WriteLine($result.Stdout)
}
if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
[Console]::Error.WriteLine($result.Stderr)
}
return $null
}

$output = $result.Stdout.Trim()
if ([string]::IsNullOrWhiteSpace($output)) {
return @()
}

try {
$parsed = ConvertFrom-Json -InputObject $output
if ($parsed -is [System.Array]) {
return @($parsed)
}

return @()
}
catch {
return ($output -split "`r?`n" |
ForEach-Object { $_.Trim() } |
Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}
}

function Get-Timestamp {
return ((Get-Date).ToString('o') -replace '[\.:]', '-')
}

function Get-ErrorOnlyOutput {
param(
[Parameter(Mandatory = $true)][string]$RawOutput
)

$lines = $RawOutput -split "`r?`n"
$result = New-Object System.Collections.Generic.List[string]
$captureFailedTasks = $false
$lastFilePathLine = $null
$ansiEscapePattern = [regex]::Escape([string][char]27) + '\[[0-9;]*[A-Za-z]'

foreach ($line in $lines) {
$trimmed = $line.Trim()
$normalized = [regex]::Replace($trimmed, $ansiEscapePattern, '')
if ($normalized -match '^Failed tasks:') {
$result.Add($line)
$captureFailedTasks = $true
continue
}

if ($captureFailedTasks) {
if ([string]::IsNullOrWhiteSpace($normalized)) {
continue
}

if ($normalized -match '^-\s+') {
$result.Add($line)
continue
}

$captureFailedTasks = $false
}

if ([string]::IsNullOrWhiteSpace($normalized)) {
continue
}

if ($normalized -match '^[A-Za-z]:\\.*\.(ts|tsx|js|jsx|html|json)$') {
$lastFilePathLine = $line
continue
}

if ($normalized -match '(?i)\bwarnings?\b') {
continue
}

if ($normalized -match '(?i)^\s*\d+:\d+\s+(error|fatal)\b') {
if ($lastFilePathLine -and ($result.Count -eq 0 -or $result[$result.Count - 1] -ne $lastFilePathLine)) {
$result.Add($lastFilePathLine)
}
$result.Add($line)
}
}

if ($result.Count -eq 0) {
return '[no error lines detected in command output]'
}

return ($result -join [Environment]::NewLine)
}

function Write-FailureArtifacts {
param(
[Parameter(Mandatory = $true)]$CommandResult
)

$ts = Get-Timestamp
$historyLog = Join-Path $historyDir ("failure-$ts.log")
$output = "$($CommandResult.Stdout)$($CommandResult.Stderr)"
$errorOnlyOutput = Get-ErrorOnlyOutput -RawOutput $output

$summary = @(
"check_command: $checkCommand"
"exit_code: $($CommandResult.Status)"
"timestamp: $((Get-Date).ToString('o'))"
'log_scope: error_lines_only'
''
'---- filtered command output ----'
$errorOnlyOutput
) -join [Environment]::NewLine

Set-Content -LiteralPath $historyLog -Value $summary -Encoding utf8
Set-Content -LiteralPath $latestLog -Value $summary -Encoding utf8

$prompt = @(
'Copilot Autofix Request (Pre-Commit)'
''
'Strict workflow requirements (do not skip any step):'
''
'1. Review the lint failures in the log below'
'2. Fix all the lint issues in the code'
'3. Ask user to review the changes'
'4. When fixes are ready, open an interactive confirmation question using vscode_askQuestions'
'5. The question header must be: precommit_fix_confirmation'
'6. The question text must ask if I accept the fixes and want to proceed'
'7. Provide exactly two options: ACCEPT_AND_PROCEED, REJECT_AND_REWORK'
'8. Set allowFreeformInput to false so only these options can be selected'
'9. If I choose REJECT_AND_REWORK, continue fixing and ask again later'
'10. If I choose ACCEPT_AND_PROCEED, YOU must run this command yourself:'
''
' powershell -NoProfile -ExecutionPolicy Bypass -File ./tools/pre-commit/precommit-proceed.ps1'
''
'11. Do not ask me to run the command manually; execute it using your terminal tool'
'12. The proceed command will create a commit with message "chore: fixed lint issues"'
'13. The new commit will run pre-commit lint checks automatically; if they fail, continue fixing'
''
'Failure log path:'
"- $latestLog"
''
'Failure context:'
'- The attached failure log file contains only error lines from the lint output.'
'- Use that file as the single source of truth for errors to fix.'
) -join [Environment]::NewLine

Set-Content -LiteralPath $latestPrompt -Value $prompt -Encoding utf8

return [pscustomobject]@{
HistoryLog = $historyLog
LatestLog = $latestLog
LatestPrompt = $latestPrompt
}
}

function Resolve-FixCommand {
return 'powershell -NoProfile -ExecutionPolicy Bypass -File ./tools/pre-commit/copilot-autofix-precommit.ps1 "{prompt}" "{log}"'
}

function Substitute-Tokens {
param(
[Parameter(Mandatory = $true)][string]$Command,
[Parameter(Mandatory = $true)]$Files
)

return $Command.Replace('{log}', $Files.LatestLog).Replace('{prompt}', $Files.LatestPrompt).Replace('{history}', $Files.HistoryLog)
}

function Invoke-Fixer {
param(
[Parameter(Mandatory = $true)]$Files
)

$configured = Resolve-FixCommand
if ([string]::IsNullOrWhiteSpace($configured)) {
[Console]::Error.WriteLine('No Copilot auto-fix command configured for pre-commit.')
[Console]::Error.WriteLine("Failure log: $($Files.LatestLog)")
[Console]::Error.WriteLine("Prompt file: $($Files.LatestPrompt)")
return [pscustomobject]@{ Status = 1; Stdout = ''; Stderr = '' }
}

$command = Substitute-Tokens -Command $configured -Files $Files
Write-Host 'Running Copilot auto-fix command for pre-commit...'
Write-Host "Command: $command"

$result = Invoke-CommandCapture -Command $command -ExtraEnv @{
PRE_COMMIT_FAILURE_LOG = $Files.LatestLog
PRE_COMMIT_PROMPT_FILE = $Files.LatestPrompt
PRE_COMMIT_FAILURE_HISTORY = $Files.HistoryLog
}

if (-not [string]::IsNullOrWhiteSpace($result.Stdout)) {
Write-Host $result.Stdout
}
if (-not [string]::IsNullOrWhiteSpace($result.Stderr)) {
[Console]::Error.WriteLine($result.Stderr)
}

return $result
}

function Main {
Ensure-Folders

if (Should-CheckAffectedLint) {
if (-not (Test-HasLintRelevantStagedChanges)) {
Write-Host ("No staged {0} files found. Skipping pre-commit lint checks." -f ($lintRelevantExtensions -join '/'))
exit 0
}

Write-Host 'Checking for affected lint projects...'
$affectedLintProjects = Get-AffectedLintProjects

if ($null -ne $affectedLintProjects -and $affectedLintProjects.Count -eq 0) {
Write-Host 'No affected lint projects found. Skipping pre-commit lint checks.'
exit 0
}
}

Write-Host 'Running pre-commit lint checks...'
$checkResult = Invoke-CommandWithLiveOutput -Command $checkCommand

if ($checkResult.Status -eq 0) {
Write-Host 'Pre-commit lint checks passed. Commit can continue.'
exit 0
}

$files = Write-FailureArtifacts -CommandResult $checkResult
[Console]::Error.WriteLine("Pre-commit lint checks failed. Failure written to: $($files.LatestLog)")

$fixResult = Invoke-Fixer -Files $files
if ($fixResult.Status -ne 0) {
[Console]::Error.WriteLine('Copilot auto-fix command failed or is not configured. Aborting commit.')
exit 1
}

[Console]::Error.WriteLine('Copilot autofix context opened. Commit is stopped; continue from Copilot workflow.')
exit 1
}

Main