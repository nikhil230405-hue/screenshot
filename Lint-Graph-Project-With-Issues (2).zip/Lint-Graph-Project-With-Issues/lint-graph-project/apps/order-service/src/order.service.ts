import { Order } from "./order.model";
import { OrderRepository } from "./order.repository";

export class OrderService {
  private readonly repository = new OrderRepository();

  listRecentOrders(): Order[] {
    const statuses = ["NEW", "PAID"];

    if (statuses.length === 0) {
      return [];
    }

    const orders = this.repository.findByStatus("PAID");
    const order = orders[0];

    if (order) {
      const adjustedOrder = { ...order, total: order.total * 1.1 };
      return [adjustedOrder];
    }

    return orders;
  }

  shutdown(): void {
  }
}
